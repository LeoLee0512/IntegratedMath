# 基础数学公开来源检索与许可审查

核查日：2026-10-20。检索方式为无需登录的公开 HTTPS GET，最大并发为 3，不绕过访问控制。正文第一至第五章的题干、解答、论证和图示均独立编写；以下资料用于来源发现、许可辨别和后续阅读，不作为转载材料。

## 结果及其限度

实际访问 WeBWorK Open Problem Library 的 8 个 Rochester 主题目录，发现并取得 257 个公开题目文件。仅在内存中检查文件，没有把题目正文或答案表达式保存到分发资料；台账记录原始 URL、元数据、文件字节数、SHA-256 和静态存在性标记。

| 目录 | 发现并取得的题目文件数 |
|---|---:|
| 实数基础 | 46 |
| 指数与根式 | 61 |
| 线性方程 | 14 |
| 二次方程 | 34 |
| 计数 | 29 |
| 概率 | 25 |
| 导数 | 35 |
| Newton 方法 | 13 |
| 合计 | 257 |

70 个文件检测到显式答案判定函数，174 个文件检测到显式判定函数或 PGML 答案绑定，98 个文件检测到解答区块。这是源文件静态标记，不是对解答正确性的验证；没有相应标记也不等于文件没有答案。257 个文件中 161 个有教材题源元数据，这进一步说明不能仅凭“开源题库”名称就确认所有原始来源的权利。

## B01：WeBWorK Open Problem Library

- 作者：OpenWeBWorK 社区；具体贡献的权利由作者保留。
- 项目：<https://github.com/openwebwork/webwork-open-problem-library>。
- 实际取得的许可声明：<https://raw.githubusercontent.com/openwebwork/webwork-open-problem-library/master/OPL_LICENSE>，HTTP 200。
- 关键许可短摘：“Unless otherwise indicated, all contributions ... are licensed under ... Attribution-NonCommercial-ShareAlike 3.0”。完整声明还允许具体贡献另行明确开放许可。
- 决定：本稿不转载其题干、解答、插图或翻译。默认许可包含非商业、署名和相同方式共享条件；具体题源仍需逐题核验。许可声明不等于对一切第三方原题的权利担保。
- 元数据文件：`sources_basic.json`；检索程序：`retrieve_basic.py`。

## B02：Active Calculus — Single Variable

- 作者：Matthew Boelkins，及原书署名贡献者 David Austin、Steven Schlicker 等。
- 项目：<https://github.com/active-calculus/active-calculus-single-mbx>。
- 实际取得的许可文件：<https://raw.githubusercontent.com/active-calculus/active-calculus-single-mbx/master/source/colophon.xml>，HTTP 200。
- 文件头声明 CC BY-SA；所检查的文件头没有给出具体版本，不能擅自写成 4.0。
- 实际取得解答手册结构：<https://raw.githubusercontent.com/active-calculus/active-calculus-single-mbx/master/source/acs-solution-manual.ptx>，HTTP 200。
- 实际取得代表性章节：<https://raw.githubusercontent.com/active-calculus/active-calculus-single-mbx/master/source/sec-1-1-vel.xml>，HTTP 200。
- 决定：列为公开阅读资源；本稿不转载、改编或翻译其内容。已确认解答手册源入口，不声称已逐题取得或核验整本书的解答。

## B03：A First Course in Linear Algebra

- 作者：Robert A. Beezer。
- 项目：<https://github.com/rbeezer/fcla>。
- 已取得 README：<https://raw.githubusercontent.com/rbeezer/fcla/master/README.md>，HTTP 200。
- README 自述 GFDL 许可，完整许可条款未在本次基础组核验。
- 决定：候选参考，不在正文中采用或转载。

## B04–B06：受网络限制的候选源

| 键 | URL | 实际结果 | 决定 |
|---|---|---|---|
| B04 | https://openstax.org/license | 代理 CONNECT 403 | 未核验、未采用 |
| B05 | https://math.libretexts.org/Bookshelves/PreAlgebra | 代理 CONNECT 403 | 未核验、未采用 |
| B06 | https://aimath.org/textbooks/approved-textbooks/ | 代理 CONNECT 403 | 未核验、未采用 |

公开可下载与允许在任何条件下再发行是不同问题。本次没有通过替换凭证、规避代理或登录私有账户访问这些站点。网络失败不构成对这些站点整体合法性或公开性的评价。

## 原创基础稿

`manuscript/01_foundations.md` 包含第一至第五章：绪论，计数与自然数，测量与几何，方程与消元，整数与证明。共有 24 道编号原创练习及完整解答，另有 7 道编号例题。图 2.1 和图 3.1 是本稿代码绘制的原创数学示意图，代码位于 `tools/draw_foundations.py`。

这些正文内容不是 529 章或 6022 分支的已完成替代品。外部题库元数据数不等于书稿原创习题数，也不等于已审校的题目数。
