# 分析学来源核验记录

访问日期：2026-10-20。记录为本次真实 HTTP 请求结果，不把搜索候选当作已阅读文献。

## 已访问并核验许可

- **LEBL-RA**：Jiří Lebl，*Basic Analysis: Introduction to Real Analysis*，作者公开 GitHub 仓库 `jirilebl/ra`。已读取主文件 `realanal.tex` 的版权和双许可段落，并读取数列与级数、连续函数、导数、黎曼积分四章。许可为 CC BY-SA 4.0 或 CC BY-NC-SA 4.0 二择一；封面等另行标注作品不据此重用。官方原始文件：https://raw.githubusercontent.com/jirilebl/ra/master/realanal.tex 。
- **LEBL-DE**：Jiří Lebl，*Notes on Diffy Qs: Differential Equations for Engineers*，第六版、源码声明版本 6.11，作者公开 GitHub 仓库 `jirilebl/diffyqs`。主文件及一阶常微分方程、Fourier/PDE、Laplace 变换、非线性系统四章实际获取。双许可同上，图片例外不进入本书。https://raw.githubusercontent.com/jirilebl/diffyqs/master/diffyqs.tex 。
- **MATHLIB-MeanValue**：The mathlib Community，`Mathlib/Analysis/Calculus/MeanValue.lean`；同时读取导数基础及积分文件，核验根目录 `LICENSE` 为 Apache-2.0。用于检查中值结论适用条件的形式化表达；本次未执行 Lean 编译，不能把来源项目已经形式化与本书已经形式化混为一谈。https://raw.githubusercontent.com/leanprover-community/mathlib4/master/Mathlib/Analysis/Calculus/MeanValue.lean 。

共保存 14 份成功获取的文件（其中包括许可证），每条文件 SHA-256 见 JSON 台账。作者和许可正文保留在下载文件中；该资料目录不得从原文件中删除版权、许可与特殊素材例外说明。

## 本次不可访问的入口

`www.jirka.org`、`ocw.mit.edu`、`math.libretexts.org`、`arxiv.org` 的相应请求被代理 CONNECT 403 拒绝。没有绕过网络规则，没有登录，没有请求任何令牌。arXiv 候选页未读取，也没有任何 arXiv 论文内容进入分析正文；失败的 URL 不是参考文献。

## 使用方式与验证边界

正文为标准数学事实的独立中文阐释，所有例题和练习独立编写，没有将来源题目、解答、插图或连续文字移入书稿。下载的开放源码只是许可允许的研究资料，不自动将本书的独立表达变成该源码的翻译。若后续直接改写或复制 CC BY-SA 素材，必须重新逐项记录派生来源、署名和相同方式共享要求。

本单元有 7 章、21 道课后练习并给出解答。证明与未展开导读明确区分。热方程候选解的偏微分残差、边界值，爆破 ODE 残差，Volterra 积分方程候选解，以及递推式前七次精确恒等式，已用 SymPy 补充核算。符号核算不能替代条件证明、唯一性证明或对未知问题的研究。
