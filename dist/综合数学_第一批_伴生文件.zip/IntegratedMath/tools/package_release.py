"""Package original work and provenance metadata, excluding external source texts."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[1]
files=[]
for folder in ["manuscript","tools","data","figures"]:
    files += [p for p in (ROOT/folder).rglob("*") if p.is_file() and "__pycache__" not in p.parts]
files += [p for p in (ROOT/"research").glob("*") if p.suffix in [".json",".md"]]
files += [ROOT/"README.md",ROOT/"EDITORIAL_POLICY.md",ROOT/"requirements-build.txt"]
files += [ROOT/"dist"/name for name in ["综合数学.pdf","综合数学.md","综合数学.html","style.css"]]
files += list((ROOT/"dist/figures").glob("*.png"))
files += list((ROOT/"build/screenshots").glob("*.png"))
files += [ROOT/"build/page-contact-sheet.png",ROOT/"build/pdf-build.log"]
files=sorted(set(files))
assert all(p.is_file() for p in files)
assert not any(p.name=="MSC_2020.pdf" or p.name=="msc2020_uploaded.txt" for p in files)
manifest={}
for path in files:
    manifest[str(path.relative_to(ROOT))]=hashlib.sha256(path.read_bytes()).hexdigest()
(ROOT/"dist/SHA256SUMS.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
files += [ROOT/"dist/SHA256SUMS.json"]
target=ROOT/"dist/综合数学_第一批_伴生文件.zip"
with zipfile.ZipFile(target,"w",zipfile.ZIP_DEFLATED) as z:
    for path in files:
        z.write(path,Path("IntegratedMath")/path.relative_to(ROOT))
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
print(json.dumps({"files":len(files),"zip_bytes":target.stat().st_size,
                  "path":str(target)},ensure_ascii=False))
