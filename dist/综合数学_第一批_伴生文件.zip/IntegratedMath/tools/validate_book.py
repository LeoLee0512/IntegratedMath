"""Check artifact consistency and render real PDF pages for visual inspection."""
from pathlib import Path
import json
import re
import subprocess
import hashlib
import fitz

ROOT = Path(__file__).resolve().parents[1]
text = (ROOT/"dist/综合数学.md").read_text()
manifest = json.loads((ROOT/"data/chapter_manifest.json").read_text())
taxonomy = json.loads((ROOT/"data/msc_taxonomy.json").read_text())
domains = json.loads((ROOT/"data/domain_plan.json").read_text())
assert len(manifest) == 35
assert len(domains) == 63
assert taxonomy["counts"]["intermediate"] == 534
assert taxonomy["counts"]["all_leaf"] == 6006
assert len(re.findall(r"^# 第.+章 ",text,re.M)) == len(manifest)
catalog_validation=json.loads((ROOT/'data/catalog_validation.json').read_text())
assert catalog_validation['catalog_checks']['heading_counts']=={'部分':63,'章':534,'节':6006}
assert len(re.findall(r'^## 第\d+部分 ',text,re.M))==63
assert len(re.findall(r'^### 第\d+章 ',text,re.M))==534
assert len(re.findall(r'^- 第\d+节 ',text,re.M))==6006
revision=json.loads((ROOT/'data/revision_validation.json').read_text())
assert revision['total_questions']==revision['total_solutions']==110
images = re.findall(r"!\[[\s\S]*?\]\(([^)]+)\)",text)
for path in images:
    assert (ROOT/"dist"/path).is_file(), path
ast = json.loads(subprocess.check_output(["pandoc","dist/综合数学.md","-t","json"],cwd=ROOT))
counts = {}
def walk(node):
    if isinstance(node,dict):
        if "t" in node: counts[node["t"]] = counts.get(node["t"],0)+1
        for value in node.values(): walk(value)
    elif isinstance(node,list):
        for value in node:walk(value)
walk(ast)
assert counts.get("Math",0) > 500
assert counts.get("Image",0) == len(images)
html=(ROOT/"dist/综合数学.html").read_text()
assert "<math" in html
assert "<script" not in html, "Offline HTML must not depend on remote scripts."
log=(ROOT/"build/pdf-build.log").read_text()+(ROOT/'build/catalog-pdf-build.log').read_text()
bad_glyphs=[line for line in log.splitlines() if "Missing character" in line]
pdf=fitz.open(ROOT/"dist/综合数学.pdf")
assert len(pdf)>30
pdf_text="\n".join(page.get_text() for page in pdf)
assert "Leo Lee" in pdf_text
assert "绪论" in pdf_text and "附录" in pdf_text
assert "$$" not in pdf_text
assert "\ufffd" not in pdf_text
forward_links=[]
back_links=[]
answer_start=next(i for i,page in enumerate(pdf) if '附录六课后题参考答案' in page.get_text().replace(' ','' ) and '返回题目' in page.get_text())
for i,page in enumerate(pdf):
    for link in page.get_links():
        label=''.join(page.get_textbox(link['from']).split())
        if label=='参考答案':
            assert link.get('page',-1)>=answer_start
            forward_links.append((i,link['page']))
        elif label=='返回题目':
            assert 0<=link.get('page',-1)<answer_start
            back_links.append((i,link['page']))
assert len(forward_links)==len(back_links)==110, (len(forward_links),len(back_links))
overflow=[]
for i,page in enumerate(pdf):
    for word in page.get_text("words"):
        x0,y0,x1,y1,*_=word
        if x0<8 or x1>page.rect.width-8 or y0<8 or y1>page.rect.height-8:
            overflow.append({"page":i+1,"box":[x0,y0,x1,y1],"text":word[4]})
out=ROOT/"build/screenshots"
out.mkdir(exist_ok=True)
for previous in out.glob('page-*.png'):
    previous.unlink()
selected=sorted(set([0,1,2, min(5,len(pdf)-1),len(pdf)//4,len(pdf)//2,
                     3*len(pdf)//4,len(pdf)-3,len(pdf)-1]))
for needle in ["def bayes_example", "图 2.1", "平方根存在性", "附录六课后题", "附录六 课后题", "本章练习", "第6006节"]:
    found=next((i for i,p in enumerate(pdf) if needle in p.get_text()),None)
    if found is not None:selected.append(found)
selected=sorted(set(selected))
for index in selected:
    pdf[index].get_pixmap(matrix=fitz.Matrix(1.2,1.2)).save(out/f"page-{index+1:03}.png")
from PIL import Image, ImageOps, ImageDraw
thumbs=[]
for index in selected:
    im=Image.open(out/f"page-{index+1:03}.png").convert("RGB")
    im.thumbnail((280,390))
    thumb=Image.new("RGB",(300,425),"#dfe6ec")
    thumb.paste(im,((300-im.width)//2,10))
    ImageDraw.Draw(thumb).text((10,405),f"PDF page {index+1}",fill="black")
    thumbs.append(thumb)
sheet=Image.new("RGB",(900,425*((len(thumbs)+2)//3)),"white")
for i,im in enumerate(thumbs):sheet.paste(im,((i%3)*300,(i//3)*425))
sheet.save(ROOT/"build/page-contact-sheet.png")
report={
 "status":"automated_checks_passed" if not bad_glyphs and not overflow else "requires_layout_review",
 "chapters":len(manifest),"pdf_pages":len(pdf),"markdown_math_nodes":counts.get("Math",0),
 "catalog_counts":catalog_validation['catalog_checks']['heading_counts'],
 "exercise_questions_and_answers":110,
 "pdf_question_to_answer_links":len(forward_links),
 "pdf_answer_to_question_links":len(back_links),
 "embedded_figure_references":len(images),"missing_glyph_warnings":bad_glyphs,
 "page_boundary_overflow":overflow,"rendered_pages":[i+1 for i in selected],
 "visual_review":"Rendered screenshots require actual human/model visual inspection; not inferred from rendering.",
 "pdf_sha256":hashlib.sha256((ROOT/"dist/综合数学.pdf").read_bytes()).hexdigest(),
 "validation_limits":"Syntax, consistency, numerical checks and selected proof review do not certify all mathematics or complete MSC coverage."
}
catalog_pdf=fitz.open(ROOT/'dist/综合数学_完整数学目录.pdf')
report['standalone_catalog_pdf_pages']=len(catalog_pdf)
catalog_text=''.join(p.get_text() for p in catalog_pdf)
assert '第6006节' in catalog_text.replace(' ','')
(ROOT/"data/build_validation.json").write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({k:(len(v) if k in ["missing_glyph_warnings","page_boundary_overflow"] else v) for k,v in report.items()},ensure_ascii=False,indent=2))
if bad_glyphs or overflow:
    raise SystemExit("Resolve or inspect layout issues before delivery.")
