"""Validate source-to-question/answer pairing after assembly; never re-extract answers from question-only prose."""
from pathlib import Path
import json
import re
from assemble_book import collect, ORDER
from separate_exercises import split_exercises

ROOT = Path(__file__).resolve().parents[1]
source = collect()
expected = []
for chapter, title in enumerate(ORDER, 1):
    _, rows = split_exercises(source[title]['text'].strip().replace('以上七章','本组七章'), chapter)
    expected.extend(rows)
_, rows = split_exercises((ROOT/'manuscript/appendix_foundations.md').read_text(), 'APP01')
expected.extend(rows)
actual = [json.loads(line) for line in (ROOT/'data/original_exercises.jsonl').read_text().splitlines()]
assert expected == actual, 'Source/answer dataset mismatch'
assert len(actual) == 110 and len({row['id'] for row in actual}) == 110
text = (ROOT/'dist/综合数学.md').read_text()
body, answer_appendix = text.split('# 附录六 课后题参考答案',1)
for row in actual:
    assert body.count('{#question-'+row['id']+'}') == 1
    assert answer_appendix.count('{#answer-'+row['id']+'}') == 1
    assert row['solution_markdown'] in answer_appendix
assert len(re.findall(r'^\*\*(?:解答|解)[。．:：]?\*\*',body,re.M)) == 12
for marker in ['进一步阅读。','核验说明。','范围声明。','常见误解。','前沿与边界。']:
    assert '**'+marker+'**' in body, marker
    assert '**'+marker+'**' not in answer_appendix, marker
captions = re.findall(r'!\[(.*?)\]\(figures/[^)]*\)',text,re.S)
assert len(captions) == 10 and all('原创' not in caption for caption in captions)
assert '本书收录的每一张插图均由本书配套代码原创绘制' in body
report = dict(status='passed',body_exercises=109,appendix_exercises=1,
              total_questions=110,total_solutions=110,unique_ids=110,
              worked_example_answers_preserved=12,commentary_boundaries_preserved=True,
              figure_captions_without_repeated_originality=10,
              solutions_equal_source=True,question_answer_links_paired=True)
(ROOT/'data/revision_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False))
