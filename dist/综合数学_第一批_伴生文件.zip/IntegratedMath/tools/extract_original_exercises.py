"""Extract the book's own exercises and solutions, never third-party questions."""
from pathlib import Path
import json
import re

ROOT=Path(__file__).resolve().parents[1]
text=(ROOT/"dist/综合数学.md").read_text()
chunks=list(re.finditer(r"^# 第[^\n]+章 [^\n]+\n([\s\S]*?)(?=^# |\Z)",text,re.M))
records=[]
for chapter, chunk in enumerate(chunks,1):
    body=chunk.group(1)
    matches=list(re.finditer(r"^\*\*(练习\s+[^*\n]+|题[一二三四五六七八九十]+。|G\d+-\d+。)\*\*",body,re.M))
    for index, match in enumerate(matches):
        end=matches[index+1].start() if index+1<len(matches) else len(body)
        block=body[match.end():end]
        block=re.split(r"\n(?:#{1,3} |!\[|\*\*(?:来源|深入|连接|资料说明|代码与来源|本章对应))",block,maxsplit=1)[0]
        solution=re.search(r"\*\*(?:解答|解)[。．:：]?\*\*",block)
        if solution is None:
            raise ValueError(f"Missing solution: chapter {chapter}, {match.group(1)}")
        records.append({
            "id":f"CH{chapter:02d}-EX{index+1:02d}",
            "chapter":chapter,"original_label":match.group(1).rstrip("。"),
            "question_markdown":block[:solution.start()].strip(),
            "solution_markdown":block[solution.end():].strip(),
            "provenance":"为《综合数学》独立编写；未转载外部题库题干或答案",
            "verification_status":"正文审读及部分符号/数值核查；非逐题机器形式化证明",
        })
assert records and all(r["question_markdown"] and r["solution_markdown"] for r in records)
(ROOT/"data/original_exercises.jsonl").write_text(
    "\n".join(json.dumps(r,ensure_ascii=False) for r in records)+"\n")
(ROOT/"data/exercise_summary.json").write_text(json.dumps({
    "extracted_original_exercises":len(records),
    "chapters_with_exercises":len({r["chapter"] for r in records}),
    "scope":"Numbered body exercises only; worked examples and supplemental appendix questions are additional.",
},ensure_ascii=False,indent=2))
print(f"Extracted {len(records)} original exercises with nonempty solutions.")
