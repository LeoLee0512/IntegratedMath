"""Assemble reviewed, original chapters; never generate placeholder textbook text."""
from pathlib import Path
import json
import re
import shutil
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
from build_domain_plan import main as domain_plan

ORDER = [
    "绪论", "计数、自然数与基本运算", "测量、分数与实用几何",
    "方程、消元与算法", "整数性质与证明的方法",
    "三角量：由直角三角形走向测量", "记数法、比例与代数表示",
    "符号代数、复数计算与对数的入口", "坐标与曲线：用方程描述形状",
    "从机会问题到概率计算", "变化与累积：微积分的形成",
    "运动的方程：常微分方程与变分", "力学：变化、能量与模型的边界",
    "曲线、曲面与局部测量", "无穷与严谨性：实分析、级数和逼近",
    "频率与复变量：十九世纪分析的扩展",
    "向量、方程与十九世纪的结构语言", "群、环与可以撤销的操作",
    "整除、有限域与方程的算术", "距离、凸性与非欧几何的边界",
    "计数、偏序与一般代数的共同语言", "量词、证明与数学基础",
    "拓扑：连续变化中保留什么", "从长度到测度：二十世纪积分的语言",
    "函数成为点：泛函分析与算子",
    "多变量的演化：偏微分方程、动力系统与研究边界",
    "场、介质与现代物理的数学入口", "统计：从有限观测到有条件的结论",
    "从局部坐标到同伦与整体分析", "范畴、同调与 K 理论的第一座桥",
    "数值分析：近似值必须带着理由", "运筹、优化与多个决策者",
    "控制、种群与反应网络", "信息、编码与计算的界限",
    "走到研究边界：小和集与可以检查的进展",
]

CHAPTER_DOMAINS = {
    1:["00","01","97"], 2:["00","97"], 3:["51"], 4:["15","65"], 5:["11"],
    6:["51","85"], 7:["00","01"], 8:["12","30"], 9:["14","51"],
    10:["60"], 11:["26"], 12:["34","39","49"], 13:["70","85"],
    14:["53"], 15:["26","40","41"], 16:["30","31","32","33","42","43","44"],
    17:["15"], 18:["16","17","20","22"], 19:["11","12","13"],
    20:["51","52"], 21:["05","06","08"], 22:["03"],
    23:["54"], 24:["28"], 25:["45","46","47"],
    26:["35","37"], 27:["74","76","78","80","81","82","83","86"],
    28:["62"], 29:["14","53","55","57","58"], 30:["18","19"],
    31:["65"], 32:["90","91"], 33:["92","93"], 34:["68","94"],
    35:["05","20","68"],
}

FIGURES = {
    3: ("triangle", "原创图：矩形的对角线把它分成两个面积相同的三角形。底长为 $b$、对应高为 $h$，每个三角形面积为 $bh/2$；公式依据见本章证明。"),
    7: ("numberline", "原创图：数轴上的 $-2+3=1$。向右移动三个单位；位置与移动量不要混淆。"),
    10: ("binomial", "原创图：三次独立公平投掷，$X$ 表示正面次数，则 $P(X=k)=\\binom3k/8$，$k=0,1,2,3$。柱高依次为 $1/8,3/8,3/8,1/8$。"),
    11: ("tangent", "原创图：$f(x)=x^2$ 在 $x=1$ 处的切线是 $y=2x-1$；斜率为 $f'(1)=2$。图像帮助理解，导数公式由本章极限计算证明。"),
    15: ("riemann", "原创图：$f(x)=x^2$ 在 $[0,1]$ 上的左端点阶梯和。等分为 $n$ 段时，阶梯在第 $j$ 段取值 $(j/n)^2$，$j=0,\\ldots,n-1$；两条阶梯分别取 $n=4,12$。"),
    16: ("unit_circle", "原创图：复平面中的单位圆与 $e^{i\\theta}=\\cos\\theta+i\\sin\\theta$。横、纵坐标分别为实部与虚部；此图不代替指数恒等式的证明。"),
    29: ("topology", "原创图：三角形的边界与包含内部的闭三角形是两个不同的空间。右图含一个二维面；比较同调时，不能漏掉这个面。本图只说明对象，代数计算见链复形章节。"),
    33: ("feedback", "原创图：负反馈的信号关系 $u=K(r-y)$，其中 $r$ 为目标、$y$ 为输出、$K$ 为增益。连线表示信号传递，不表示已经证明任何系统都稳定。"),
}

def chinese(n):
    digits = "零一二三四五六七八九"
    if n < 10: return digits[n]
    if n < 20: return "十" + (digits[n % 10] if n % 10 else "")
    return digits[n // 10] + "十" + (digits[n % 10] if n % 10 else "")

def collect():
    result = {}
    for path in sorted((ROOT/"manuscript").glob("[0-9]*.md")):
        text = path.read_text()
        for match in re.finditer(r"^# (.+)\n([\s\S]*?)(?=^# |\Z)", text, re.M):
            raw, body = match.group(1), match.group(2)
            anchor = re.search(r"\{#([^}]+)\}", raw)
            name = re.sub(r"\s*\{#[^}]+\}", "", raw)
            name = re.sub(r"^第[一二三四五六七八九十百0-9]+章\s*", "", name)
            if name in result:
                raise ValueError("Duplicate chapter " + name)
            result[name] = {"source": str(path.relative_to(ROOT)), "text": body,
                            "anchor": anchor.group(1) if anchor else None}
    if set(result) != set(ORDER):
        raise ValueError({"missing": set(ORDER)-set(result), "extra":set(result)-set(ORDER)})
    return result

def collect_source_summary():
    records = []
    for path in sorted((ROOT/"research").glob("sources_*.json")):
        data = json.loads(path.read_text())
        rows = data if isinstance(data,list) else data.get("records",data.get("sources",[]))
        for row in rows:
            status = row.get("http_status",row.get("status",row.get("access","")))
            ok = status == 200 or status == "verified_http_200" or row.get("access_verified") is True
            records.append({"ledger":path.name, "url":row.get("url"), "success":ok})
    unique = {}
    for row in records:
        url = row["url"]
        if url:
            if url not in unique or row["success"]:
                unique[url] = row
    basic = json.loads((ROOT/"research/sources_basic.json").read_text())
    questions = [r for r in basic["records"] if r.get("kind")=="problem_metadata"]
    summary = {"top_level_source_records":len(records),
               "unique_recorded_urls":len(unique),
               "unique_urls_with_recorded_success":sum(r["success"] for r in unique.values()),
               "problem_file_metadata_records":len(questions),
               "solution_block_detected":sum(bool(r.get("has_solution_block")) for r in questions),
               "answer_checker_detected":sum(bool(r.get("has_answer_checker")) for r in questions),
               "answer_checker_or_binding_detected":sum(bool(r.get("has_answer_checker") or r.get("has_pgml_answer_binding")) for r in questions),
               "caution":"Counts of recorded source-level entries, not number of papers read or verified exercises. Nested requests may not be included. Source problem bodies are excluded from the distribution."}
    (ROOT/"data/retrieval_summary.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2))
    return summary

def bibliography():
    text = """# 附录四 来源、许可与核验边界

检索日期为 2026 年 10 月 20 日。正文的教学组织、例题、解答和示意图独立编写；下列来源用于事实核查、进一步阅读或记录检索范围。开放许可仍有条件；原作者文字、题目、图片、代码和论文 PDF 的权限不能互相代替。题库清单记录是否发现答案结构，未将其逐题正确性审校算作已完成。

## 教材、题库与形式化资料

"""
    basic = json.loads((ROOT/"research/sources_basic.json").read_text())
    selected = basic["bibliography"][:2]
    a = json.loads((ROOT/"research/sources_analysis.json").read_text())
    selected += [r for r in a if r.get("id") in ["LEBL-RA","LEBL-DE","MATHLIB-MeanValue"]]
    g = json.loads((ROOT/"research/sources_geometry.json").read_text())["sources"]
    selected += g[:5]
    ap = json.loads((ROOT/"research/sources_applications.json").read_text())["sources"]
    selected += ap[:4]
    for r in selected:
        ident = r.get("id","")
        title = r.get("title",r.get("url","来源"))
        author = r.get("author","").replace("Jiří","J.")
        url = r.get("url",r.get("license_evidence_url",""))
        license_text = r.get("license",r.get("observed_license",r.get("license_observed","详见对应来源台账")))
        text += f"- **[{ident}]** {author}；[{title}]({url})。许可记录：{license_text}。\n\n"
    text += """- **[ALG-STACKS]** The Stacks Project Authors，[The Stacks Project](https://github.com/stacks/stacks-project)。实际读取 algebra、fields、categories、homology 及许可说明；GNU Free Documentation License 1.2 或更新版的具体适用证据见 `research/sources_algebra.json`。未复制文档正文。

- **[ALG-MATHLIB]** mathlib contributors，[mathlib4](https://github.com/leanprover-community/mathlib4)，Apache-2.0。读取部分定义、素数无穷与分析相关形式化源码，不声称本机已经编译这些项目。

- **[MSC2020]** Mathematical Reviews 与 zbMATH，*Mathematics Subject Classification 2020*，用户提供的 224 页 PDF。分类代码、定位页与短标题索引见伴生数据；附件再分发许可未核实，分发包不含原 PDF 或全文抽取文本。

## 前沿资料

前沿章节列出三篇带作者、标题、arXiv 编号和链接的论文；书目信息由作者项目元数据间接核查，论文全文、独立许可和最终期刊状态没有在本次核实。公开项目 [PFR](https://github.com/teorth/pfr) 与 [Sphere eversion](https://github.com/leanprover-community/sphere-eversion) 的实际访问和 Apache-2.0 许可记录见 `research/sources_frontier.json`。项目自报形式化状态与本机独立验证严格区分。

## 尚未通过访问或权利核验的材料

OpenStax、LibreTexts、AIM、MacTutor、Hatcher 部分官网、Clay 页面及 arXiv 本体在本次访问中受到网络限制；具体失败记录见各台账。没有把失败请求当作已经读取资料。题献参考中的肖像与拉普拉斯引语暂未取得充分可追溯证据，未收入本稿。

"""
    return text

def main():
    (ROOT/"dist").mkdir(exist_ok=True)
    chapters = collect()
    domains = domain_plan()
    summary = collect_source_summary()
    manifest = []
    output = """---
title: 综合数学
author: Leo Lee
date: 二〇二六年
lang: zh-CN
documentclass: article
---

"""
    for n, name in enumerate(ORDER,1):
        record = chapters[name]
        anchor = record["anchor"] or f"chapter-{n:02d}"
        body = record["text"].strip().replace("以上七章","本组七章")
        # Stable local subsection numbering without changing theorem identifiers.
        section = 0
        def renumber(match):
            nonlocal section
            section += 1
            title = re.sub(r"^\d+\.\d+\s+","",match.group(1))
            return f"## {n}.{section} {title}"
        body = re.sub(r"^## (.+)$",renumber,body,flags=re.M)
        if n == 1:
            body += """

## 1.6 本批范围与阅读路线

本批为第一批工作稿，保留全书目标，尚未完成全部学科与分支。已写正文与仅作导读的内容在各章明确区分。章节采用历史阶段为主线，允许在某一阶段集中讲清一个观念；章节内以现代语言补充定义和证明，不将这些补充伪装成古代原文。古代方程不等于十九世纪向量空间，早期机会计算不等于二十世纪概率公理化。

第一至第五章建立基础；其后经三角、记数、符号与坐标进入近代变化和概率，再到严谨分析、结构、逻辑、拓扑与现代应用。每个阶段仍有待扩写的课题。查学科时使用附录三的 63 类索引；查完整 MSC 条目时使用伴生的 JSON/CSV。历史顺序不替代先修依赖，选读者须查看章首约定及补充证明。

"""
        if n in FIGURES:
            file, caption = FIGURES[n]
            body += f"\n\n![{caption}](figures/{file}.png){{width=82%}}\n"
        output += f"# 第{chinese(n)}章 {name} {{#{anchor}}}\n\n{body}\n\n"
        manifest.append({"chapter":n,"title":name,"anchor":anchor,
                         "source":record["source"],"msc_major":CHAPTER_DOMAINS[n],
                         "han_characters":len(re.findall(r"[\u4e00-\u9fff]",body)),
                         "status":"本批选讲已写；不是该领域完整章节体系"})
    output += (ROOT/"manuscript/appendix_foundations.md").read_text() + "\n\n"
    output += """# 附录二 可执行的计算与图示

所有下列数据均为人工构造的教学数据，不代表现实调查。严格结论依赖正文的公式与证明；程序断言只作有限算例的交叉检查，不等于形式化证明。二分法内部用有理数保持区间证书，小数显示仍会舍入。Euler 误差界只适用于正文指定的初值问题和步长。

## 计算结果

"""
    results = json.loads((ROOT/"data/numerical_results.json").read_text())
    output += f"""贝叶斯例的阳性概率为 $7/50$，后验为 $9/28$；人工样本 $2,4,6$ 的均值为 $4$、无偏样本方差为 $4$。二分法 20 步所得中点为有理数 ${results['bisection']['midpoint_exact']}$，根与中点的绝对误差不超过 ${results['bisection']['absolute_error_bound_exact']}$。Euler 法取 $h=1/10$，在 $t=1$ 处近似为 $0.3486784401$，正文证明的绝对误差上界为 $1/20$。线性规划的上界证书给出最优值 $10$，在 $(2,2)$ 达到。

完整结果保存在 `data/numerical_results.json`。运行命令为：

```bash
python tools/numerical_examples.py
python tools/check_foundations.py
```

## 计算附录完整代码

```python
"""
    output += (ROOT/"tools/numerical_examples.py").read_text()
    output += "\n```\n\n"
    output += """## 原创插图的可复现公式

插图脚本 `tools/generate_figures.py` 与 `tools/draw_foundations.py` 随书提供。主脚本的数学输入分别为：$7=5+2$；三角形面积 $bh/2$；数轴 $-2+3=1$；曲线 $y=x^2$ 与切线 $y=2x-1$；左端点阶梯 $(j/n)^2$；单位圆 $(\\cos\\theta,\\sin\\theta)$；三角形边界与填充；二项概率 $\\binom3k/8$；反馈信号 $u=K(r-y)$。图中采样仅用于绘图，不作为收敛、拓扑或稳定性的证明。

"""
    output += "# 附录三 63 个学科部分与完整分类索引\n\n"
    output += """这 63 个部分是全书范围的学科索引，不是 63 个已经完成的独立卷。上传附件经两种 PDF 引擎逐项复核，得到 63 大类、534 中类及 6006 末级条目；其中 5503 项为专门主题，503 项为通用文献类型。用户已确认以附件实际分类为准。没有把全部末级条目误写为已经完成的教学分支。

每个下列入口仅表示本批选讲或导读所在位置。全部领域的完整教材仍待逐批补齐；数学史和数学教育目前主要体现在编排与阅读说明中，还不是这两个研究领域的完整课程。

| MSC | 学科部分 | 本批入口章 | 与其他学科交叉 |
|:---:|---|---|---|
"""
    for row in domains:
        matching = [m for m in manifest if row["msc"] in m["msc_major"]]
        row["current_chapters"] = [m["chapter"] for m in matching]
        refs = "、".join(f"[{m['chapter']}](#{m['anchor']})" for m in matching)
        output += f"|{row['msc']}|{row['title']}|{refs}|{row['intersections']}|\n"
    output += """
完整机器可读索引为 `data/msc_taxonomy.json` 与 `data/msc_taxonomy.csv`，含层级、父节点、附件页码、代码及短标题。末级条目的 `writing_status=not_written` 表示该条目的完整专门教学内容尚未完成，并不否认选讲正文提到其相关概念。`data/chapter_manifest.json` 记录实际正文；`data/domain_plan.json` 记录 63 类入口。三者用途不同，不可混算进度。

"""
    output += bibliography()
    output += """# 附录五 审校范围与下一批工作

本批已进行不同子代理之间的独立数学审读、精确算术与符号检查、数值程序运行，以及最终 PDF 的编译与页面渲染检查。发现并修复的具体问题和实际检查范围保存在 `research/independent_math_review.md`。这些检查不能替代后续专业学者的系统审稿，也不代表任何未写分支已经通过审核。

后续仍需按历史主线扩展每个中级主题，补齐定义、先修依赖、完整证明、图解、例题及逐题解答；逐项维护来源和许可；对前沿状态进行新的可靠来源核查。控制收敛定理、一般谱理论、伽罗瓦理论、概形、高阶同调、研究级 PDE 等在本批尚未完成系统教学。正文中明确标注的未证明定理和导读不计作已完成证明。

目录、索引、元数据和可运行脚本已交付；整个《综合数学》的最终写作目标仍然保留，不能由这一批工作稿替代。
"""
    output = output.replace("Jiří Lebl", "J. Lebl")
    (ROOT/"dist/综合数学.md").write_text(output)
    (ROOT/"data/chapter_manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
    (ROOT/"data/domain_plan.json").write_text(json.dumps(domains,ensure_ascii=False,indent=2))
    for p in (ROOT/"figures").glob("*.png"):
        (ROOT/"dist/figures").mkdir(exist_ok=True)
        shutil.copy2(p,ROOT/"dist/figures"/p.name)
    print(json.dumps({"chapters":len(manifest),"han_characters":sum(r["han_characters"] for r in manifest),
                      "retrieval":summary},ensure_ascii=False))

if __name__=="__main__":
    main()
