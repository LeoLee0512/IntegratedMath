"""Exact arithmetic and algebra checks for selected foundation examples.
Not a proof checker; human proof review remains separate.
"""
from fractions import Fraction as F
from math import gcd
from pathlib import Path
import json
import sympy as sp
checks=[]
def record(name,condition):
    value=bool(condition)
    checks.append({'name':name,'passed':value})
    assert value,name
record('pens-distributivity',12*(7+3)==12*7+12*3==120)
record('29-divmod-6',divmod(29,6)==(4,5))
record('base-two-1011',int('1011',2)==11)
record('fraction-sum',F(2,3)+F(5,6)==F(3,2))
record('fraction-product',F(2,3)*F(5,6)==F(5,9))
record('rectangle-area',F(7,2)*F(4,3)==F(14,3))
record('rectangle-perimeter',2*(F(7,2)+F(4,3))==F(29,3))
record('pythagoras-3-4-5',3**2+4**2==5**2)
record('pythagoras-5-12-13',5**2+12**2==13**2)
a,b,da,db=sp.symbols('a b da db')
record('exact-area-error-identity',sp.expand((a+da)*(b+db)-a*b-(b*da+a*db+da*db))==0)
record('exact-area-error-example',(F(10)+F(1,10))*(F(4)-F(1,5))-40==F(-81,50))
record('two-variable-example',2*4+3==11 and 4-3==1)
record('price-example',2*6+5==17 and 6+2*5==16)
record('gcd-252-105',gcd(252,105)==21)
record('bezout-example',5*105-2*252==21)
record('gcd-198-84',gcd(198,84)==6)
record('euclid-product-composite',2*3*5*7*11*13+1==30031==59*509)
record('83-divmod-7',divmod(83,7)==(11,6))
a,b,c,d,e,f=sp.symbols('a b c d e f')
record('linear-system-first-numerator',sp.expand(a*(e*d-b*f)+b*(a*f-c*e)-e*(a*d-b*c))==0)
record('linear-system-second-numerator',sp.expand(c*(e*d-b*f)+d*(a*f-c*e)-f*(a*d-b*c))==0)
n=sp.symbols('n',integer=True)
record('odd-square-identity',sp.expand((2*n+1)**2-(2*(2*n*n+2*n)+1))==0)
record('mod-three-remainder-two-square',sp.expand((3*n+2)**2-(3*(3*n*n+4*n+1)+1))==0)
result={'checks':checks,'passed':len(checks),'scope':'Exact arithmetic and symbolic identities only; no numerical floating-point approximation and no machine verification of all prose proofs.'}
ROOT=Path(__file__).resolve().parents[1]
(ROOT/'research/foundations_validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({'passed':len(checks),'failed':0}))
