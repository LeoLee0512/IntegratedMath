#!/usr/bin/env python3
"""《综合数学》原创可复核例题；仅使用 Python 标准库。

本文件中的观测数据全部是教学用的人工构造数据。
运行: python3 tools/numerical_examples.py
不下载数据，不访问网络，不依赖外部代码。
"""

from fractions import Fraction
import json
import math


def bayes_example():
    prior = Fraction(1, 20)
    sensitivity = Fraction(9, 10)
    false_alarm = Fraction(1, 10)
    positive = sensitivity * prior + false_alarm * (1 - prior)
    posterior = sensitivity * prior / positive
    assert positive == Fraction(7, 50)
    assert posterior == Fraction(9, 28)
    return {"positive_probability": str(positive), "posterior": str(posterior)}


def bisection_sqrt_two(steps=20):
    """在有理数中精确更新区间，不用浮点符号判断。"""
    if not isinstance(steps, int) or steps < 0:
        raise ValueError("steps 必须是非负整数")
    left, right = Fraction(1), Fraction(2)
    for _ in range(steps):
        middle = (left + right) / 2
        value = middle * middle - 2
        if value == 0:
            left = right = middle
            break
        if value < 0:
            left = middle
        else:
            right = middle
    assert left * left <= 2 <= right * right
    assert right - left <= Fraction(1, 2**steps)
    midpoint = (left + right) / 2
    error_bound = (right - left) / 2
    return {
        "steps": steps,
        "left_exact": str(left),
        "right_exact": str(right),
        "midpoint_exact": str(midpoint),
        "midpoint_decimal": float(midpoint),
        "absolute_error_bound_exact": str(error_bound),
    }


def euler_decay(steps=10):
    """x'=-x, x(0)=1, T=1；有理数迭代与浮点解析值对照。"""
    if not isinstance(steps, int) or steps < 1:
        raise ValueError("steps 必须是正整数")
    step = Fraction(1, steps)
    value = Fraction(1)
    for _ in range(steps):
        value *= 1 - step
    assert value == (1 - step) ** steps
    bound = step / 2
    analytic_float = math.exp(-1)
    observed_float_error = abs(float(value) - analytic_float)
    assert observed_float_error <= float(bound) + 1e-15
    return {
        "steps": steps,
        "h_exact": str(step),
        "x_at_1_exact": str(value),
        "x_at_1_decimal": float(value),
        "analytic_float": analytic_float,
        "observed_float_error": observed_float_error,
        "proved_error_bound_exact": str(bound),
    }


def elementary_statistics():
    sample = [Fraction(2), Fraction(4), Fraction(6)]
    n = len(sample)
    mean = sum(sample) / n
    sample_variance = sum((v - mean) ** 2 for v in sample) / (n - 1)
    assert mean == 4 and sample_variance == 4
    return {
        "artificial_sample": [str(v) for v in sample],
        "mean_exact": str(mean),
        "sample_variance_exact": str(sample_variance),
    }


def linear_program():
    """max 3x+2y; x,y>=0, x+y<=4, x<=2。"""
    vertices = [(0, 0), (2, 0), (2, 2), (0, 4)]
    values = []
    for x, y in vertices:
        assert x >= 0 and y >= 0 and x + y <= 4 and x <= 2
        values.append(3 * x + 2 * y)
    optimum_index = max(range(len(vertices)), key=values.__getitem__)
    assert vertices[optimum_index] == (2, 2) and values[optimum_index] == 10
    # 正文另有上界证书 3x+2y=2(x+y)+x<=10，故不靠枚举证明最优。
    return {"vertices": vertices, "objective_values": values, "optimum": [2, 2, 10]}


def binary_entropy(p):
    if not 0 <= p <= 1:
        raise ValueError("p 必须在 [0,1] 中")
    return sum(-q * math.log2(q) for q in [p, 1 - p] if q > 0)


def run():
    assert binary_entropy(0) == 0
    assert binary_entropy(1) == 0
    assert binary_entropy(0.5) == 1
    assert math.isclose(binary_entropy(0.25), binary_entropy(0.75))
    results = {
        "data_origin": "原创教学用人工构造数据；不是经验观测",
        "bayes": bayes_example(),
        "statistics": elementary_statistics(),
        "bisection": bisection_sqrt_two(),
        "euler": euler_decay(),
        "linear_program": linear_program(),
        "entropy": {"H(0.5)": binary_entropy(0.5), "H(0.25)": binary_entropy(0.25)},
    }
    return results


if __name__ == "__main__":
    print(json.dumps(run(), ensure_ascii=False, indent=2))
