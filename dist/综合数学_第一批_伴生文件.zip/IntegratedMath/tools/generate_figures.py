"""Generate original explanatory figures. No third-party images or datasets."""
from pathlib import Path
import os

ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault("MPLCONFIGDIR", str(ROOT / "build" / "mpl"))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle, FancyArrowPatch
import numpy as np

OUT = ROOT / "figures"
OUT.mkdir(exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 12,
                     "axes.spines.top": False, "axes.spines.right": False})
BLUE, GOLD = "#245c85", "#d78622"

def save(fig, name):
    fig.savefig(OUT / f"{name}.png", dpi=180, bbox_inches="tight", facecolor="white")
    fig.savefig(OUT / f"{name}.pdf", bbox_inches="tight", facecolor="white")
    plt.close(fig)

fig, ax = plt.subplots(figsize=(7, 2.4))
for i in range(10):
    ax.add_patch(Rectangle((i % 5, i // 5), 1, 1, fill=False, edgecolor=BLUE))
    if i < 7:
        ax.add_patch(Circle((i % 5 + .5, i // 5 + .5), .2, color=GOLD))
ax.set(xlim=(-.2, 7), ylim=(-.2, 2.3), aspect="equal")
ax.text(5.3, 1.1, r"$7=5+2$"); ax.axis("off")
save(fig, "counting")

fig, ax = plt.subplots(figsize=(6, 3.4))
ax.add_patch(Rectangle((0, 0), 5, 3, fill=False, edgecolor=BLUE, linewidth=2))
ax.plot([0, 5], [0, 3], color=GOLD, linewidth=2)
ax.text(2.5, -.5, r"$b$"); ax.text(-.5, 1.5, r"$h$")
ax.text(3.1, .7, r"$A=\frac{1}{2}bh$", fontsize=18)
ax.set(xlim=(-.8, 5.4), ylim=(-.8, 3.4), aspect="equal"); ax.axis("off")
save(fig, "triangle")

fig, ax = plt.subplots(figsize=(6.5, 2.5))
ax.axhline(0, color=BLUE)
for x in range(-3, 4):
    ax.plot([x, x], [-.08, .08], color=BLUE)
    ax.text(x, -.3, str(x), ha="center")
ax.add_patch(FancyArrowPatch((-2, .2), (1, .2), connectionstyle="arc3,rad=-.35",
                            arrowstyle="->", mutation_scale=15, color=GOLD))
ax.text(-.5, .8, r"$-2+3=1$", ha="center")
ax.set(xlim=(-3.6, 3.6), ylim=(-.6, 1.3)); ax.axis("off")
save(fig, "numberline")

fig, ax = plt.subplots(figsize=(6, 4))
x = np.linspace(-.3, 2.4, 200)
ax.plot(x, x*x, label=r"$f(x)=x^2$", color=BLUE)
ax.plot(x, 2*x-1, "--", label=r"$y=2x-1$", color=GOLD)
ax.scatter([1], [1], color=GOLD)
ax.set(xlabel=r"$x$", ylabel=r"$y$", ylim=(-1, 6)); ax.legend()
save(fig, "tangent")

fig, ax = plt.subplots(figsize=(6, 4))
for n, color in [(4, BLUE), (12, GOLD)]:
    left = np.arange(n)/n
    ax.step(np.r_[left, 1], np.r_[left*left, left[-1]**2],
            where="post", label=rf"$n={n}$", color=color)
x = np.linspace(0, 1, 201)
ax.plot(x, x*x, "k--", alpha=.6, label=r"$x^2$")
ax.set(xlabel=r"$x$", ylabel=r"$y$"); ax.legend()
save(fig, "riemann")

fig, ax = plt.subplots(figsize=(5, 5))
theta = np.linspace(0, 2*np.pi, 300)
ax.plot(np.cos(theta), np.sin(theta), color=BLUE)
ang = np.pi/4
ax.arrow(0, 0, .94*np.cos(ang), .94*np.sin(ang), width=.01,
         color=GOLD, length_includes_head=True, head_width=.07)
ax.axhline(0, color="gray", linewidth=.5); ax.axvline(0, color="gray", linewidth=.5)
ax.text(.55, .85, r"$e^{i\theta}$"); ax.text(.3, .1, r"$\theta$")
ax.set(xlabel=r"$\operatorname{Re}z$", ylabel=r"$\operatorname{Im}z$", aspect="equal")
save(fig, "unit_circle")

fig, axes = plt.subplots(1, 2, figsize=(7, 3))
points = np.array([[0, 0], [1, 0], [.5, .85]])
for ax, filled, title in zip(axes, [False, True], ["boundary", "filled triangle"]):
    ax.fill(points[:, 0], points[:, 1], color=BLUE, alpha=.2 if filled else 0)
    q = np.vstack([points, points[0]])
    ax.plot(q[:, 0], q[:, 1], color=BLUE)
    ax.scatter(points[:, 0], points[:, 1], color=GOLD)
    ax.set_title(title); ax.set(aspect="equal", xlim=(-.2, 1.2), ylim=(-.2, 1.1))
    ax.axis("off")
save(fig, "topology")

fig, ax = plt.subplots(figsize=(6, 3.5))
values = [0, 1, 2, 3]
prob = np.array([1, 3, 3, 1])/8
ax.bar(values, prob, color=BLUE)
ax.set(xticks=values, xlabel=r"$k$", ylabel=r"$P(X=k)$", ylim=(0, .45))
for k, p in zip(values, prob):
    ax.text(k, p+.015, f"{int(p*8)}/8", ha="center")
save(fig, "binomial")

fig, ax = plt.subplots(figsize=(6, 3))
for x, text in [(0, r"$r$"), (2, r"$u=K(r-y)$"), (5, "system"), (7, r"$y$")]:
    ax.text(x, 0, text, ha="center", va="center",
            bbox={"boxstyle": "round,pad=.4", "facecolor": "white", "edgecolor": BLUE})
for a, b in [(.4, 1.1), (3.1, 4.3), (5.7, 6.7)]:
    ax.annotate("", (b, 0), (a, 0), arrowprops={"arrowstyle": "->", "color": BLUE})
ax.plot([7, 7, 2, 2], [-.2, -1, -1, -.3], color=GOLD)
ax.text(4.5, -1.35, "negative feedback", ha="center")
ax.set(xlim=(-.5, 7.6), ylim=(-1.7, .6)); ax.axis("off")
save(fig, "feedback")

print(f"Generated {len(list(OUT.glob('*.png')))} original figures.")
