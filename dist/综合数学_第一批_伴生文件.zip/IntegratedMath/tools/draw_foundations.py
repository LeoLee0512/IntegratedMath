"""Original exact geometric illustrations; no downloaded images."""
from pathlib import Path
import os
os.environ.setdefault('MPLCONFIGDIR','/tmp/integratedmath-matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, Rectangle
from matplotlib.font_manager import FontProperties
ROOT=Path(__file__).resolve().parents[1]
FONT=FontProperties(fname='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')

def label(ax,x,y,text,**kw):
    ax.text(x,y,text,fontproperties=FONT,ha='center',va='center',**kw)

fig,ax=plt.subplots(figsize=(7,4.4))
for row in range(3):
    for col in range(4):
        ax.add_patch(Rectangle((col,row),1,1,facecolor=['#e7f1fa','#cfe3f2','#b6d4e8'][row],edgecolor='#294b63'))
        ax.plot(col+.5,row+.5,'o',color='#204f74',markersize=10)
label(ax,2,3.3,'4 列，每列 3 个')
label(ax,2,-.35,'3 行，每行 4 个：总数都是 12')
ax.set(xlim=(-.4,4.4),ylim=(-.7,3.6),aspect='equal');ax.axis('off')
fig.savefig(ROOT/'figures/foundations_counting.png',dpi=180,bbox_inches='tight');plt.close(fig)

a,b=3,4;L=a+b
fig,ax=plt.subplots(figsize=(6.2,6.2))
triangles=[[(0,0),(a,0),(0,b)],[(L,0),(a,0),(L,a)],[(L,L),(L,a),(b,L)],[(0,L),(b,L),(0,b)]]
for tri in triangles:ax.add_patch(Polygon(tri,facecolor='#d9e9f3',edgecolor='#234b66',linewidth=1.5))
ax.add_patch(Polygon([(a,0),(L,a),(b,L),(0,b)],facecolor='#f7e7bb',edgecolor='#234b66',linewidth=1.5))
label(ax,a/2,-.3,'a = 3');label(ax,(a+L)/2,-.3,'b = 4')
label(ax,-.38,b/2,'b');label(ax,-.38,(b+L)/2,'a')
label(ax,L/2,L/2,'中央正方形\n边长 c = 5\n面积 c²',fontsize=13)
label(ax,L/2,L+.4,'四个直角三角形与中央正方形恰好铺满')
ax.set(xlim=(-.8,L+.4),ylim=(-.8,L+.8),aspect='equal');ax.axis('off')
fig.savefig(ROOT/'figures/foundations_pythagoras.png',dpi=180,bbox_inches='tight');plt.close(fig)
