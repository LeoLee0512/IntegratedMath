#!/usr/bin/env python3
"""Audit MSC codes from the user-provided PDF; never infer editorial chapter counts."""
from pathlib import Path
import argparse, csv, hashlib, json, re, subprocess


TOP_CHINESE = dict(line.split('|',1) for line in """00|数学总论与综合主题
01|数学史与人物传记
03|数理逻辑与数学基础
05|组合数学
06|序、格与有序代数结构
08|一般代数系统
11|数论
12|域论与多项式
13|交换代数
14|代数几何
15|线性与多重线性代数、矩阵理论
16|结合环与结合代数
17|非结合环与非结合代数
18|范畴论与同调代数
19|K理论
20|群论及其推广
22|拓扑群与李群
26|实函数
28|测度与积分
30|单复变函数
31|位势论
32|多复变函数与解析空间
33|特殊函数
34|常微分方程
35|偏微分方程
37|动力系统与遍历论
39|差分方程与函数方程
40|序列、级数与可和性
41|逼近与展开
42|欧氏空间上的调和分析
43|抽象调和分析
44|积分变换与算子演算
45|积分方程
46|泛函分析
47|算子理论
49|变分法、最优控制与优化
51|几何学
52|凸几何与离散几何
53|微分几何
54|一般拓扑学
55|代数拓扑学
57|流形与胞腔复形
58|整体分析与流形上的分析
60|概率论与随机过程
62|统计学
65|数值分析
68|计算机科学
70|质点与系统力学
74|可变形固体力学
76|流体力学
78|光学与电磁理论
80|经典热力学与热传递
81|量子理论
82|统计力学与物质结构
83|相对论与引力理论
85|天文学与天体物理学
86|地球物理学
90|运筹学与数学规划
91|博弈论、经济学、社会与行为科学
92|生物学及其他自然科学
93|系统理论与控制
94|信息、通信与电路
97|数学教育""".splitlines())

CODE = re.compile(r'^\s*(\d{2}-XX|\d{2}[A-Z]xx|\d{2}[A-Z]\d{2}|\d{2}-\d{2})\s+(.+)$')

def extract(text):
    entries=[]
    current=None
    for page_number, page in enumerate(text.split('\f'),1):
        for line in page.splitlines():
            match=CODE.match(line)
            if match:
                code,title=match.groups()
                level='major' if code.endswith('-XX') else 'intermediate' if code.endswith('xx') else 'general_leaf' if '-' in code else 'subject_leaf'
                parent=None if level=='major' else code[:2]+'-XX' if level in ('intermediate','general_leaf') else code[:3]+'xx'
                current={'code':code,'level':level,'parent_code':parent,'pdf_page':page_number,'_title':[title.strip()]}
                entries.append(current)
            elif current and line.strip() and not line.strip().isdigit():
                current['_title'].append(line.strip())
    for e in entries:
        title=' '.join(e.pop('_title'))
        title=re.split(r'\s*[\[{]',title,maxsplit=1)[0]
        title=re.sub(r'\s+',' ',title).strip()
        e['title_short']=title[:160]
        e['title_truncated']=len(title)>160
        e['title_zh']=TOP_CHINESE.get(e['code'][:2],'') if e['level']=='major' else ''
        e['writing_status']='not_written'
    codes=[e['code'] for e in entries]
    assert len(codes)==len(set(codes)), 'Duplicate heading codes require manual review'
    known=set(codes)
    assert all(e['parent_code'] is None or e['parent_code'] in known for e in entries)
    return entries

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('pdf',type=Path)
    parser.add_argument('--output-dir',type=Path,default=Path(__file__).resolve().parents[1]/'data')
    args=parser.parse_args()
    text=subprocess.run(['pdftotext','-layout',str(args.pdf),'-'],capture_output=True,text=True,check=True).stdout
    entries=extract(text)
    counts={level:sum(e['level']==level for e in entries) for level in ['major','intermediate','subject_leaf','general_leaf']}
    counts['all_leaf']=counts['subject_leaf']+counts['general_leaf']
    # An independent PDF text engine and set comparison guards against layout losses.
    import fitz
    pdf=fitz.open(args.pdf)
    independent='\n'.join(p.get_text() for p in pdf)
    independent_codes={m.group(1) for line in independent.splitlines() if (m:=CODE.match(line))}
    primary_codes={e['code'] for e in entries}
    assert primary_codes==independent_codes, {'only_pdftotext':sorted(primary_codes-independent_codes),'only_pymupdf':sorted(independent_codes-primary_codes)}
    result={'source':'User supplied MSC_2020.pdf; Mathematical Reviews and zbMATH, MSC2020','source_sha256':hashlib.sha256(args.pdf.read_bytes()).hexdigest(),'source_pages':len(pdf),'counts':counts,'independent_crosscheck':'pdftotext -layout and PyMuPDF exact heading-code set equality','requested_counts':{'major':63,'intermediate':529,'all_leaf':6022},'rights_note':'Bibliographic classification index extracted from a user-supplied document. No open license was verified for the attachment. Do not redistribute the original PDF or assume this index licenses source prose. Entries are identifiers and short descriptive labels, not textbook chapters.','entries':entries}
    args.output_dir.mkdir(parents=True,exist_ok=True)
    (args.output_dir/'msc_taxonomy.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    with (args.output_dir/'msc_taxonomy.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(entries[0]));writer.writeheader();writer.writerows(entries)
    print(json.dumps({'counts':counts,'pages':len(pdf),'codes_compared':len(primary_codes),'sha256':result['source_sha256']},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
