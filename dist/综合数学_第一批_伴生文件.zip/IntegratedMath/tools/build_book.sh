#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build dist build/fontcache
export XDG_CACHE_HOME="$PWD/build/fontcache"
python tools/generate_figures.py
python tools/draw_foundations.py
python tools/numerical_examples.py > data/numerical_results.json
python tools/check_foundations.py
python tools/assemble_book.py
python tools/extract_original_exercises.py
pandoc dist/综合数学.md --standalone --toc --toc-depth=1 \
  --resource-path=.:dist --mathml -o dist/综合数学.html \
  --metadata lang=zh-CN --css=style.css
pandoc dist/综合数学.md --standalone --toc --toc-depth=1 \
  --resource-path=.:dist --pdf-engine=xelatex \
  -V mainfont='Noto Serif CJK SC' -V sansfont='Noto Sans CJK SC' \
  -V monofont='Noto Sans Mono CJK SC' -V monofontoptions='AutoFakeSlant=0.15' \
  -V geometry:margin=22mm \
  -V fontsize=11pt -V colorlinks=true -V linkcolor=blue \
  -H tools/pdf_header.tex -o dist/综合数学.pdf \
  2>build/pdf-build.log
python tools/validate_book.py
