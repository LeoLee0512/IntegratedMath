#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build dist build/fontcache
export XDG_CACHE_HOME="$PWD/build/fontcache"
python tools/generate_figures.py
python tools/draw_foundations.py
python tools/numerical_examples.py > data/numerical_results.json
python tools/check_foundations.py
python tools/build_full_catalog.py
python tools/assemble_book.py
python tools/extract_original_exercises.py
pandoc dist/综合数学.md --standalone --toc --toc-depth=1 \
  --resource-path=.:dist --mathml -o dist/综合数学.html \
  --metadata lang=zh-CN --css=style.css
pandoc dist/综合数学.md --standalone --toc --toc-depth=1 \
  --resource-path=.:dist --pdf-engine=xelatex \
  -V mainfont='Noto Serif CJK SC' -V sansfont='Noto Sans CJK SC' \
  -V monofont='Noto Sans Mono CJK SC' -V monofontoptions='AutoFakeSlant=0.15' \
  -V geometry:margin=22mm \
  -V fontsize=11pt -V colorlinks=true -V linkcolor=blue \
  -H tools/pdf_header.tex -o dist/综合数学.pdf \
  2>build/pdf-build.log
python - <<'PY'
from pathlib import Path
from tools.assemble_book import full_catalog_for_book
text='---\ntitle: 综合数学 · 完整数学目录\nauthor: Leo Lee\nlang: zh-CN\n---\n\n'+full_catalog_for_book()
Path('build/catalog-print.md').write_text(text)
header=Path('tools/pdf_header.tex').read_text().split('\\renewcommand{\\maketitle}',1)[0]
Path('build/catalog-header.tex').write_text(header)
PY
pandoc build/catalog-print.md --standalone --pdf-engine=xelatex \
  -V mainfont='Noto Serif CJK SC' -V sansfont='Noto Sans CJK SC' \
  -V monofont='Noto Sans Mono CJK SC' -V monofontoptions='AutoFakeSlant=0.15' \
  -V geometry:margin=22mm -V fontsize=11pt \
  -H build/catalog-header.tex -o dist/综合数学_完整数学目录.pdf \
  2>build/catalog-pdf-build.log
python tools/validate_book.py
