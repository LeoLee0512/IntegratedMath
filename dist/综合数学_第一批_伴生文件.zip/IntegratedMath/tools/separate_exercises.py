"""Move existing exercise solutions without moving adjacent commentary."""
import re

QUESTION = re.compile(r'^\*\*(练习\s+[^*\n]+|题[一二三四五六七八九十]+。|G\d+-\d+。)\*\*', re.M)
ANSWER = re.compile(r'^\*\*(?:解答|解)[。．:：]?\*\*', re.M)

def split_exercises(body, chapter):
    matches = list(QUESTION.finditer(body))
    records, replacements = [], []
    for i, match in enumerate(matches):
        end = matches[i+1].start() if i+1 < len(matches) else len(body)
        tail = body[match.end():end]
        answer = ANSWER.search(tail)
        if answer is None:
            raise ValueError(f'Missing answer: {chapter} {match.group(1)}')
        question = tail[:answer.start()].strip()
        after_answer = tail[answer.end():]
        # All existing solution bodies were audited: a following bold paragraph
        # is commentary, not a solution step. Preserve that paragraph in place.
        boundary = re.search(r'^#{1,6} |^!\[|^\*\*', after_answer, re.M)
        length = boundary.start() if boundary else len(after_answer)
        solution = after_answer[:length].strip()
        assert question and solution
        ident = f'CH{chapter:02d}-EX{i+1:02d}' if isinstance(chapter,int) else f'{chapter}-EX{i+1:02d}'
        label = match.group(1).rstrip('。')
        records.append(dict(id=ident, chapter=chapter, original_label=label,
                            question_markdown=question, solution_markdown=solution,
                            provenance='为《综合数学》独立编写；未转载外部题库题干或答案',
                            verification_status='正文审读及部分符号/数值核查；非逐题机器形式化证明'))
        stop = match.end()+answer.end()+length
        replacement = f'[**{match.group(1)}**]{{#question-{ident}}} {question}\n\n[参考答案](#answer-{ident})\n\n'
        replacements.append((match.start(),stop,replacement))
    for start, stop, replacement in reversed(replacements):
        body = body[:start]+replacement+body[stop:]
    for a,b in [('课后题与完整解答','课后题'),('课后题与解答','课后题'),
                ('本章练习与完整解答','本章练习'),('本章练习与解答','本章练习'),
                ('练习与完整解答','练习'),('练习与解答','练习')]:
        body = re.sub(r'^(## .*?)'+re.escape(a),lambda m:m.group(1)+b,body,flags=re.M)
    return body, records

def solution_appendix(records, chapter_titles):
    text = '# 附录六 课后题参考答案 {#exercise-solutions}\n\n按正文阅读章次和原题号排列。每题附返回题目的链接；例题的示范解答仍紧随例题。\n\n'
    previous = None
    for row in records:
        chapter = row['chapter']
        if chapter != previous:
            heading = f'正文第{chapter}章　{chapter_titles[chapter-1]}' if isinstance(chapter,int) else '附录一补充练习'
            text += f'## {heading}\n\n'
            previous = chapter
        text += f"### {row['original_label']} {{#answer-{row['id']}}}\n\n"
        text += row['solution_markdown']+f"\n\n[返回题目](#question-{row['id']})\n\n"
    return text
